

package algorithm.finalproject;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
/**
 *
 * @author mlegi
 */
public class FinalProject {
    
public static double Fibonacci(double n){
    if(n == 0){
        return 0;
    }else if(n ==1){
        return 1;
    }
    else{
        double fibCurr= 1;
        double fibNext= 0;
        double fibPrev = 0;
        for(int i = 2; i <= n; i++){
            fibNext= fibCurr + fibPrev;
            fibPrev = fibCurr;
            fibCurr = fibNext;
        }
        return fibCurr;
    }
   
}
public static long FibonacciIter(long n){
    if(n == 0){
        return 0;
    }else if(n ==1){
        return 1;
    }
    else{
        long fibCurr= 1
                 ;
        long fibNext= 0;
        long fibPrev = 0;
        for(int i = 2; i <= n; i++){
            fibNext= fibCurr + fibPrev;
            fibPrev = fibCurr;
            fibCurr = fibNext;
        }
        return fibCurr;
    }
   
}
public static long FibonacciRecursion(long n){
    if(n ==0){
        return 0;
    }else if (n == 1){
    return FibonacciRecursion(n-1) + 1;
    }
    else{
       
        return FibonacciRecursion(n-1) + FibonacciRecursion(n-2);
    }
}
 public static long MemoFibonacci(long n) {
         Map<Long, Long> memo = new HashMap<>();
        if (n <= 1) {
            return n;
        }
        if (memo.containsKey(n)) {
            return memo.get(n);
        } else {
            long result = MemoFibonacci(n - 1) + MemoFibonacci(n - 2);
            memo.put(n, result);
            return result;
        }
 }

    public static void main(String[] args) {
        long i = 1;
        long n = 13;
        while(i <= 4){
       Fibonacci(n);
        System.out.println("Showing the nth number in the fibonacci sequence. ");
        System.out.println(Fibonacci(n));
        System.out.println("Showing the runtime for using the fibonacci by iteration: ");
        long startTime = System.currentTimeMillis();
        FibonacciIter(n);
        long endTime = System.currentTimeMillis();
        long executionTimeMilliseconds = endTime - startTime;
        long seconds = executionTimeMilliseconds / 1000;
        System.out.println("The iterative fibonacci sequence takes " + executionTimeMilliseconds + " milliseconds. ");
        System.out.println("-----------------------------------------------");
        
        System.out.println("Showing the runtime for using the fibonacci by Recusion on the nth number: ");
        startTime = System.currentTimeMillis();
        FibonacciRecursion(n);
        endTime = System.currentTimeMillis();
        executionTimeMilliseconds = endTime - startTime;
        seconds = executionTimeMilliseconds / 1000;
        System.out.println("The recursive fibonacci sequence takes " + executionTimeMilliseconds + " milliseconds. ");
        System.out.println("-----------------------------------------------");
        
        System.out.println("Showing the runtime for using the fibonacci by memoization on the nth number: ");
        startTime = System.currentTimeMillis();
        MemoFibonacci(n);
        endTime = System.currentTimeMillis();
        executionTimeMilliseconds = endTime - startTime;
        seconds = executionTimeMilliseconds / 1000;
        System.out.println("The memoization fibonacci sequence takes " + executionTimeMilliseconds + " milliseconds. ");
        System.out.println("-----------------------------------------------");
        i++;
        n += 13;
        }
    }
}
